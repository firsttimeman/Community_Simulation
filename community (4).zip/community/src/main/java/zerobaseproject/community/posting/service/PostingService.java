package zerobaseproject.community.posting.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import zerobaseproject.community.posting.dto.PostingRequestDTO;
import zerobaseproject.community.posting.dto.PostingResponseDTO;
import zerobaseproject.community.posting.entity.Posting;
import zerobaseproject.community.posting.repository.PostingRepository;

@Service
@RequiredArgsConstructor
public class PostingService {

    private final PostingRepository postingRepository;

    public PostingResponseDTO createPosting(PostingRequestDTO requestDTO) {
        Posting posting = new Posting();
        posting.setTitle(requestDTO.getTitle());
        posting.setContent(requestDTO.getContent());
        posting.setCategory(requestDTO.getCategory());

        Posting save = postingRepository.save(posting);
        return PostingResponseDTO.fromEntity(save);
    }
}
